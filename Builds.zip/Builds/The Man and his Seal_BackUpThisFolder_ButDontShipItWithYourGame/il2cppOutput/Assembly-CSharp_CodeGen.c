﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void Readme::.ctor()
extern void Readme__ctor_m23AE6143BDABB863B629ADE701E2998AB8651D4C (void);
// 0x00000002 System.Void Boat::Start()
extern void Boat_Start_mEECD5ECA53299A8FEA3DF763E7AD5529903098DD (void);
// 0x00000003 System.Void Boat::Update()
extern void Boat_Update_m7FC5D5164202171B5F180CCF96D6A49C1D8F849B (void);
// 0x00000004 System.Void Boat::ChangeWeight(System.Int32)
extern void Boat_ChangeWeight_m5E4D8CD32A3CB7350FB240B6A27ABAF40188B076 (void);
// 0x00000005 System.Void Boat::SinkBoat()
extern void Boat_SinkBoat_mEEDD11B64B9DE186CB1937F5AF40A313CE1599CF (void);
// 0x00000006 System.Void Boat::.ctor()
extern void Boat__ctor_m8126A51C3AE04D6BA08FE3DCAA608C26953F66B1 (void);
// 0x00000007 System.Void DialogueManager::Start()
extern void DialogueManager_Start_m79D30C6CBBE5FB76D9421878F07DBBD5F0133F4E (void);
// 0x00000008 System.Void DialogueManager::Update()
extern void DialogueManager_Update_mDB01533DDBF392EA865355F8457D104CD3515902 (void);
// 0x00000009 System.Void DialogueManager::PrintDialog(System.String,System.String)
extern void DialogueManager_PrintDialog_mE6825684CC2A6E9B65838597B52B44807AE45992 (void);
// 0x0000000A System.Void DialogueManager::StartDialogue(Dialog)
extern void DialogueManager_StartDialogue_m0F37B5E6085116068994B8EDD767B085FEEEFA4A (void);
// 0x0000000B System.Void DialogueManager::ShowMessage(System.Boolean)
extern void DialogueManager_ShowMessage_m55D6C47EA94D37AE2DEA819B4A9DFA3A1A07008B (void);
// 0x0000000C System.Void DialogueManager::DisplayModel(System.String,System.String,System.Boolean)
extern void DialogueManager_DisplayModel_m9F53CBE2A7522F2E323CC84F94CE720E87EAEEA3 (void);
// 0x0000000D System.Void DialogueManager::StopDialogue()
extern void DialogueManager_StopDialogue_m15581B51735B3CF6C2AA87356A7C012B36F8C0C4 (void);
// 0x0000000E System.Void DialogueManager::ShowEndScreen()
extern void DialogueManager_ShowEndScreen_m4D40756A6D7BD8BC442A868E3EDE14E5A683DD73 (void);
// 0x0000000F System.Collections.IEnumerator DialogueManager::EndTransition()
extern void DialogueManager_EndTransition_mA77FD45418331E9DECCB28D0E7FB258039D37E16 (void);
// 0x00000010 System.Collections.IEnumerator DialogueManager::TextPrint(System.String)
extern void DialogueManager_TextPrint_m4C61B8B121BA016485BC4F9B0CC5DFD4DA54D576 (void);
// 0x00000011 System.Collections.IEnumerator DialogueManager::PlayDelayedSound(UnityEngine.AudioClip,System.Int32)
extern void DialogueManager_PlayDelayedSound_mA7ADBB491A6989694F2DFBCD86AAF66CE91161C8 (void);
// 0x00000012 System.Void DialogueManager::.ctor()
extern void DialogueManager__ctor_m12727264331970D05A390B4E86D3E36A2B49D711 (void);
// 0x00000013 System.Void DialogueManager::.cctor()
extern void DialogueManager__cctor_mBEC397E79DD98669EE07A84A458F29D81FE2C6C3 (void);
// 0x00000014 System.Void FishCatching::Start()
extern void FishCatching_Start_m842D74677D95D5CF87FA6DC76C1D130BAC1599BB (void);
// 0x00000015 System.Void FishCatching::Update()
extern void FishCatching_Update_m81D336ABA2B4B0EAF08E7A965FC3D2DBC288ADEE (void);
// 0x00000016 System.Void FishCatching::CommenceCatching()
extern void FishCatching_CommenceCatching_mA15D7584B172126F198E8FD6B52ADFCA170B48EC (void);
// 0x00000017 System.Void FishCatching::CaughtFish()
extern void FishCatching_CaughtFish_m88002DA218BFF3B9F1949BCFAF826DF65D4748C3 (void);
// 0x00000018 System.Void FishCatching::CaughtBottle()
extern void FishCatching_CaughtBottle_m060A33EAA3F922C82B0C6826A8D97235F1203953 (void);
// 0x00000019 System.Void FishCatching::CaughtKey()
extern void FishCatching_CaughtKey_m6BA785FA04B1DF78F4A294943D322F0B41A020F6 (void);
// 0x0000001A System.Void FishCatching::CaughtChest()
extern void FishCatching_CaughtChest_m54BCCA5F597222DC20B1DC8BD0D1B5A6881F117C (void);
// 0x0000001B System.Void FishCatching::CaughtJunk()
extern void FishCatching_CaughtJunk_mB3F4D6993F9256F16A8CFC2020C37CAFD788DB6B (void);
// 0x0000001C System.Void FishCatching::StopCatching()
extern void FishCatching_StopCatching_m60EBF8C97E16594CC811BD657568E7183668985D (void);
// 0x0000001D System.Void FishCatching::AddModelDeck(System.String)
extern void FishCatching_AddModelDeck_mA2B6CD7A17AB822147CE8BF087AC4FE7E33E1832 (void);
// 0x0000001E System.Collections.IEnumerator FishCatching::FishCatchDelay()
extern void FishCatching_FishCatchDelay_m9C520FC98449018AA355CF818D9655FACEF1FCFA (void);
// 0x0000001F System.Collections.IEnumerator FishCatching::FishBit()
extern void FishCatching_FishBit_mC051FA2FEA0127A1D8745250FB9D37258F661783 (void);
// 0x00000020 System.Void FishCatching::.ctor()
extern void FishCatching__ctor_mB1E0F6F50766F77E0737B3E4755F16E132DE8864 (void);
// 0x00000021 System.Int32 GameManager::get_FishAmount()
extern void GameManager_get_FishAmount_m5C40B20D34F685110B61469C3C5302779589E9C5 (void);
// 0x00000022 System.Void GameManager::set_FishAmount(System.Int32)
extern void GameManager_set_FishAmount_mEA9767821A5128BAD2ED4E7ACC5D1A4C9A3FA21C (void);
// 0x00000023 System.Int32 GameManager::get_LastWeight()
extern void GameManager_get_LastWeight_mF005EFF2A4E39A163DE57F8BC9F938952FC4AAB3 (void);
// 0x00000024 System.Void GameManager::set_LastWeight(System.Int32)
extern void GameManager_set_LastWeight_m82CC9B198D8C80C8DBA772FE23070E9D8FF961D1 (void);
// 0x00000025 System.Boolean GameManager::get_BottleGet()
extern void GameManager_get_BottleGet_mE2D1D3851DED7A76C3D305899C70D46A1891893D (void);
// 0x00000026 System.Void GameManager::set_BottleGet(System.Boolean)
extern void GameManager_set_BottleGet_m65493ED8EE273FF32A0C99D5AFEED9FF9CA0C606 (void);
// 0x00000027 System.Boolean GameManager::get_ChestGet()
extern void GameManager_get_ChestGet_m55142069696A0D732F07683473EE8FA3C04B762A (void);
// 0x00000028 System.Void GameManager::set_ChestGet(System.Boolean)
extern void GameManager_set_ChestGet_mB6F183775E728BDD66E71FDCF5B6735162E3B4F1 (void);
// 0x00000029 System.Boolean GameManager::get_KeyGet()
extern void GameManager_get_KeyGet_mB74A4963901A925302D88B474E015C1DAAC0822D (void);
// 0x0000002A System.Void GameManager::set_KeyGet(System.Boolean)
extern void GameManager_set_KeyGet_m3DAFB1C841E812CE51008CAD6E18D804E0BBD6B4 (void);
// 0x0000002B System.Boolean GameManager::get_GameEnd()
extern void GameManager_get_GameEnd_m05D2E0B5902A449F3D4E636E930E6B2DEBC58575 (void);
// 0x0000002C System.Void GameManager::set_GameEnd(System.Boolean)
extern void GameManager_set_GameEnd_m603A169E1DF85F8F7F0D780533968530525EF1FC (void);
// 0x0000002D System.Single GameManager::get_CamClampAngleYMax()
extern void GameManager_get_CamClampAngleYMax_mF472229EAA736B07BD92B9647B2D517465AA5784 (void);
// 0x0000002E System.Void GameManager::set_CamClampAngleYMax(System.Single)
extern void GameManager_set_CamClampAngleYMax_m080973306617EDA47DD8CD77F710972C8A55E722 (void);
// 0x0000002F System.Single GameManager::get_CamClampAngleYMin()
extern void GameManager_get_CamClampAngleYMin_mAC281A71089477B199FBB6D937D7C68ABC1DCFB1 (void);
// 0x00000030 System.Void GameManager::set_CamClampAngleYMin(System.Single)
extern void GameManager_set_CamClampAngleYMin_m93E357A1F99A12EB5E8BB20A642F2DF65BB72920 (void);
// 0x00000031 System.Void GameManager::ResetClamp()
extern void GameManager_ResetClamp_m5378BC8993B67C60FB254A2DC227F89427EE141D (void);
// 0x00000032 System.Void GameManager::Start()
extern void GameManager_Start_m4B67F69CF18652603C29FC1C5B7C6482C77B69DB (void);
// 0x00000033 System.Void GameManager::Update()
extern void GameManager_Update_mB18435F2FDDC6175F5A83AB40198635F26D6FBFB (void);
// 0x00000034 System.Void GameManager::EndGame()
extern void GameManager_EndGame_mA4F27563F51531B327D8A7AADF3D7B0A5172C539 (void);
// 0x00000035 System.Void GameManager::.ctor()
extern void GameManager__ctor_mFBEDEFD70BE58F3D3BE07FA8F9D97DE156D5C358 (void);
// 0x00000036 System.Void MainMenu::Start()
extern void MainMenu_Start_mDF8837F303DD240CE4438A6ABC3D07F7D9B3620E (void);
// 0x00000037 System.Void MainMenu::Back()
extern void MainMenu_Back_m793A776DA6C9E7D226BFD6564F5C0C992B06F57D (void);
// 0x00000038 System.Void MainMenu::StartGame()
extern void MainMenu_StartGame_mFC02626170D8FD8351C02FDAE8E0E3FE90ABBC91 (void);
// 0x00000039 System.Void MainMenu::Help()
extern void MainMenu_Help_mA56CF1BB734B561414B3694E82EDF48D81FC9E5B (void);
// 0x0000003A System.Void MainMenu::Exit()
extern void MainMenu_Exit_m3BB3296C6F5C9DD08F770F6B9B5FE51B14A58031 (void);
// 0x0000003B System.Void MainMenu::.ctor()
extern void MainMenu__ctor_m63F945D965550BD614DCD2AE7F7489D4F28C5B30 (void);
// 0x0000003C System.Void MouseLook::Start()
extern void MouseLook_Start_mEEA4981192190CE14347F5C3CEC2E533956F8F23 (void);
// 0x0000003D System.Void MouseLook::Update()
extern void MouseLook_Update_mD355F46C9D86DE6D5E64AD83D3C718950AD5775A (void);
// 0x0000003E System.Void MouseLook::CameraInit()
extern void MouseLook_CameraInit_mDD36DACE45DEC4E5F4AA1DCE0DEFD9A87901E7CE (void);
// 0x0000003F System.Void MouseLook::Rotate()
extern void MouseLook_Rotate_m8BE2026BFB6299789ADF2660091F81E183610936 (void);
// 0x00000040 System.Void MouseLook::.ctor()
extern void MouseLook__ctor_m376647F34A657513EEE22970CC3F58ED04F76776 (void);
// 0x00000041 System.Void ObjectSpin::Update()
extern void ObjectSpin_Update_mA93635E38CCF07CF065E85B957FB9D7F39A7E2A2 (void);
// 0x00000042 System.Void ObjectSpin::.ctor()
extern void ObjectSpin__ctor_m4442AA38911B03F646CF2288E510D8ACC5C36318 (void);
// 0x00000043 System.Void Player::Start()
extern void Player_Start_mD6E1D31879EB485356D1C22C8AE12C5DF6392E79 (void);
// 0x00000044 System.Void Player::Update()
extern void Player_Update_m10202D3DF1DE1AD29B6B00E0092D9C41BD3861F7 (void);
// 0x00000045 System.Void Player::ChargeRod()
extern void Player_ChargeRod_m8B975BA094F5227756DBCD104ED7100983F8D2E7 (void);
// 0x00000046 System.Void Player::ThrowBait()
extern void Player_ThrowBait_mEB5F69FBC7E90C639BBE8A96FAA511DC262567D1 (void);
// 0x00000047 System.Void Player::SetBaitLine()
extern void Player_SetBaitLine_mDB090D642C7C26C15BFE83A0BD43270E62D27EA0 (void);
// 0x00000048 System.Void Player::SetPointerPos()
extern void Player_SetPointerPos_m1F71EF4108A092B8E2C0CEDB4D24E6241F80F371 (void);
// 0x00000049 System.Collections.IEnumerator Player::disablePowerText()
extern void Player_disablePowerText_mF38CAFF2E7948D0639C3AEB83B75EE020A622F14 (void);
// 0x0000004A System.Void Player::.ctor()
extern void Player__ctor_mAEC38956EFD0E61D848D4E5AFB83BABCE2DF1E23 (void);
// 0x0000004B System.Void SceneLoader::LoadGame()
extern void SceneLoader_LoadGame_mB3D4D41C90B61E5ED79315711AD5E402B54F0D5C (void);
// 0x0000004C System.Void SceneLoader::BackToMainMenu()
extern void SceneLoader_BackToMainMenu_m79EB35A84B02551EBE237803498CA9C4E87F5AC1 (void);
// 0x0000004D System.Collections.IEnumerator SceneLoader::LoadLevel(System.Int32)
extern void SceneLoader_LoadLevel_m8739D17B6847C7DB5AC73A5DF0D647FCE22ED89C (void);
// 0x0000004E System.Void SceneLoader::.ctor()
extern void SceneLoader__ctor_mC60F58BE3954C3DF24116E3C07079A7FAC27E784 (void);
// 0x0000004F System.Void SceneLoader::.cctor()
extern void SceneLoader__cctor_m74D4EDDA5F712004EA7023E91D380BA1182831DC (void);
// 0x00000050 System.Void SoundManager::Awake()
extern void SoundManager_Awake_mB15DF04ADE8728C5E6223B353D7C921095F633C7 (void);
// 0x00000051 System.Void SoundManager::Play(UnityEngine.AudioClip)
extern void SoundManager_Play_m2B090969A0D0B4F72465FF82315B0C2C59D50106 (void);
// 0x00000052 System.Void SoundManager::PlayMusic(UnityEngine.AudioClip)
extern void SoundManager_PlayMusic_m2CC702A2235E41FD54735BD20EEA2FA6DF098538 (void);
// 0x00000053 System.Void SoundManager::PlayMusicSecond(UnityEngine.AudioClip)
extern void SoundManager_PlayMusicSecond_mF6A7C60C4B8628D865D44D7D06989A30FEB5D4AB (void);
// 0x00000054 System.Void SoundManager::RandomSoundEffect(UnityEngine.AudioClip[])
extern void SoundManager_RandomSoundEffect_m846A2F63576DF8E094E8B40994D45DE41629AA15 (void);
// 0x00000055 System.Void SoundManager::.ctor()
extern void SoundManager__ctor_mD7EC9DED92E2CC5E0271C72E21077FC66D780507 (void);
// 0x00000056 System.Void SoundManager::.cctor()
extern void SoundManager__cctor_mCC84F889230E77BD79067F9B963F41F2C223B2F0 (void);
// 0x00000057 System.Void UIManager::Start()
extern void UIManager_Start_mA404E1D4B4AA55F22307F16D7D7842CE7580DD0B (void);
// 0x00000058 System.Void UIManager::UpdateFishAmount()
extern void UIManager_UpdateFishAmount_mE212065ACD97F337B0DE432BA326E8992F91F838 (void);
// 0x00000059 System.Void UIManager::UpdateBoatWeight(System.Int32)
extern void UIManager_UpdateBoatWeight_m164E3A183D6C0539A06A55FFB19A8496AD252A40 (void);
// 0x0000005A System.Void UIManager::EnableBottleFull(System.Boolean)
extern void UIManager_EnableBottleFull_m8D22EA193BCDC13897A9C6CE19E61C320BA57035 (void);
// 0x0000005B System.Void UIManager::EnableBottleEmpty(System.Boolean)
extern void UIManager_EnableBottleEmpty_m4D87F65506B2C6F7A2472256A7C73718925DED29 (void);
// 0x0000005C System.Void UIManager::EnableKey(System.Boolean)
extern void UIManager_EnableKey_mF20148F31A6E71BE806F4D9C9AB24DF6489FB85A (void);
// 0x0000005D System.Void UIManager::EnableChest(System.Boolean)
extern void UIManager_EnableChest_m4CCE6FE0D2F90498BE92BA930CFBB5C45F503D66 (void);
// 0x0000005E System.Void UIManager::EnableBoatSank(System.Boolean)
extern void UIManager_EnableBoatSank_mABDEA5C11BBCF5ECD493BFD60C1C051A859BDB8F (void);
// 0x0000005F System.Void UIManager::EnableAlert(System.Boolean)
extern void UIManager_EnableAlert_m2DC4EC733D05A64EF409DA18BDC4AB2F3BD9736E (void);
// 0x00000060 System.Void UIManager::SetPowerText(System.String,UnityEngine.Color,System.Boolean)
extern void UIManager_SetPowerText_m85B3824502A86EFDD691C174F022016A2A0B962B (void);
// 0x00000061 System.Void UIManager::RollCredits()
extern void UIManager_RollCredits_m642537447B0EDB4F1556FE5AA0E10EE9C9DC993A (void);
// 0x00000062 System.Void UIManager::.ctor()
extern void UIManager__ctor_m5E5065654115BEE5B00F84AC64469D5D642351A3 (void);
// 0x00000063 System.Void UnityTemplateProjects.SimpleCameraController::OnEnable()
extern void SimpleCameraController_OnEnable_mE3D6E47455F101F2DEEBC2A58D09A97CF38E80B8 (void);
// 0x00000064 UnityEngine.Vector3 UnityTemplateProjects.SimpleCameraController::GetInputTranslationDirection()
extern void SimpleCameraController_GetInputTranslationDirection_m73C99DB69CEB467834BBA00A62415D1CEEF0CB47 (void);
// 0x00000065 System.Void UnityTemplateProjects.SimpleCameraController::Update()
extern void SimpleCameraController_Update_mBCD24408A4A2C4053F2F98DB808BD6DE88CA998F (void);
// 0x00000066 System.Void UnityTemplateProjects.SimpleCameraController::.ctor()
extern void SimpleCameraController__ctor_m8DE12FC1A6C31D2D60ED78F0B574CE3F864F546E (void);
// 0x00000067 System.Void Readme_Section::.ctor()
extern void Section__ctor_mE73C1D6AE5454B5A67AAB04CAA5144A5CA0B0D96 (void);
// 0x00000068 System.Void DialogueManager_<EndTransition>d__39::.ctor(System.Int32)
extern void U3CEndTransitionU3Ed__39__ctor_mF56ACAED40BC2755C4550FEC7017C227C72EE988 (void);
// 0x00000069 System.Void DialogueManager_<EndTransition>d__39::System.IDisposable.Dispose()
extern void U3CEndTransitionU3Ed__39_System_IDisposable_Dispose_mCA4BFA0602588410FF781BBA32B8B1FFBC4C4667 (void);
// 0x0000006A System.Boolean DialogueManager_<EndTransition>d__39::MoveNext()
extern void U3CEndTransitionU3Ed__39_MoveNext_m09C1B2E498E89309BB1DCD3CEBCF4667C9283D4D (void);
// 0x0000006B System.Object DialogueManager_<EndTransition>d__39::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CEndTransitionU3Ed__39_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m03932AC1FD81878391039E7A40CC46A15EE2CE64 (void);
// 0x0000006C System.Void DialogueManager_<EndTransition>d__39::System.Collections.IEnumerator.Reset()
extern void U3CEndTransitionU3Ed__39_System_Collections_IEnumerator_Reset_m41ABE9315CB73037B0B4769E292D29E73953DB64 (void);
// 0x0000006D System.Object DialogueManager_<EndTransition>d__39::System.Collections.IEnumerator.get_Current()
extern void U3CEndTransitionU3Ed__39_System_Collections_IEnumerator_get_Current_m54001C6490F198FDFCF72ABBBE7DA2FFC1F1F409 (void);
// 0x0000006E System.Void DialogueManager_<TextPrint>d__40::.ctor(System.Int32)
extern void U3CTextPrintU3Ed__40__ctor_mE16F9FF0EF2AF05457794768F17085008DDC053A (void);
// 0x0000006F System.Void DialogueManager_<TextPrint>d__40::System.IDisposable.Dispose()
extern void U3CTextPrintU3Ed__40_System_IDisposable_Dispose_m373CB6259DEFC94052D404070D83EBF4ED89BA45 (void);
// 0x00000070 System.Boolean DialogueManager_<TextPrint>d__40::MoveNext()
extern void U3CTextPrintU3Ed__40_MoveNext_m9F7DD58C30FDD1D0B48B95F2C6F82DF8CB6D5307 (void);
// 0x00000071 System.Object DialogueManager_<TextPrint>d__40::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CTextPrintU3Ed__40_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m544B913E4716A0526DB7EEEEFD11DCD8E7E4CE5C (void);
// 0x00000072 System.Void DialogueManager_<TextPrint>d__40::System.Collections.IEnumerator.Reset()
extern void U3CTextPrintU3Ed__40_System_Collections_IEnumerator_Reset_m8AB3995F050EBCDE21ECA084505DF6C2ED89EDCD (void);
// 0x00000073 System.Object DialogueManager_<TextPrint>d__40::System.Collections.IEnumerator.get_Current()
extern void U3CTextPrintU3Ed__40_System_Collections_IEnumerator_get_Current_m38ECC1B5F708102FFD9F8B62A2666D7F8A801BBC (void);
// 0x00000074 System.Void DialogueManager_<PlayDelayedSound>d__41::.ctor(System.Int32)
extern void U3CPlayDelayedSoundU3Ed__41__ctor_m5C03889C50359DE37BD5FFA075BB8DDC88EE6847 (void);
// 0x00000075 System.Void DialogueManager_<PlayDelayedSound>d__41::System.IDisposable.Dispose()
extern void U3CPlayDelayedSoundU3Ed__41_System_IDisposable_Dispose_mB0A639B29C031AA533864685F594BB776456221D (void);
// 0x00000076 System.Boolean DialogueManager_<PlayDelayedSound>d__41::MoveNext()
extern void U3CPlayDelayedSoundU3Ed__41_MoveNext_m1A55D7BA4282AED5D8CDEE72E47A1FEC2D0BC12C (void);
// 0x00000077 System.Object DialogueManager_<PlayDelayedSound>d__41::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CPlayDelayedSoundU3Ed__41_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mD5323B22FA8F936554BA64E5F3A3688C908A887B (void);
// 0x00000078 System.Void DialogueManager_<PlayDelayedSound>d__41::System.Collections.IEnumerator.Reset()
extern void U3CPlayDelayedSoundU3Ed__41_System_Collections_IEnumerator_Reset_mD98FD8648ED1560A06A7AA1ED9485D06F6E2FA57 (void);
// 0x00000079 System.Object DialogueManager_<PlayDelayedSound>d__41::System.Collections.IEnumerator.get_Current()
extern void U3CPlayDelayedSoundU3Ed__41_System_Collections_IEnumerator_get_Current_m4A82F673CBD3540999951996AC3FC788C8904316 (void);
// 0x0000007A System.Void FishCatching_<FishCatchDelay>d__30::.ctor(System.Int32)
extern void U3CFishCatchDelayU3Ed__30__ctor_m274B09FA4F96C8D3BE85423C28C15BF526C5451A (void);
// 0x0000007B System.Void FishCatching_<FishCatchDelay>d__30::System.IDisposable.Dispose()
extern void U3CFishCatchDelayU3Ed__30_System_IDisposable_Dispose_mAEDAD82F038168EE8815D24DF905586BDE7A8E7C (void);
// 0x0000007C System.Boolean FishCatching_<FishCatchDelay>d__30::MoveNext()
extern void U3CFishCatchDelayU3Ed__30_MoveNext_m8EF5B75AAAF812F5F60C566AA5B8147F9C25CAE0 (void);
// 0x0000007D System.Object FishCatching_<FishCatchDelay>d__30::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CFishCatchDelayU3Ed__30_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m7B217589608D2B3883F462FEBD69277479527056 (void);
// 0x0000007E System.Void FishCatching_<FishCatchDelay>d__30::System.Collections.IEnumerator.Reset()
extern void U3CFishCatchDelayU3Ed__30_System_Collections_IEnumerator_Reset_m6DD779F2B721FCAFDDE91D448891B354F9EFE661 (void);
// 0x0000007F System.Object FishCatching_<FishCatchDelay>d__30::System.Collections.IEnumerator.get_Current()
extern void U3CFishCatchDelayU3Ed__30_System_Collections_IEnumerator_get_Current_m6D1B4FCF314BCC0B1ECA6A5E41C910EE708CAE85 (void);
// 0x00000080 System.Void FishCatching_<FishBit>d__31::.ctor(System.Int32)
extern void U3CFishBitU3Ed__31__ctor_m504CB3444F7CAEDE4F0918F3363B7DEC2C45F36B (void);
// 0x00000081 System.Void FishCatching_<FishBit>d__31::System.IDisposable.Dispose()
extern void U3CFishBitU3Ed__31_System_IDisposable_Dispose_m71B5B022FF0006086D14CE74D59258998B169408 (void);
// 0x00000082 System.Boolean FishCatching_<FishBit>d__31::MoveNext()
extern void U3CFishBitU3Ed__31_MoveNext_mE32D5E2866C14B1B8AF577A9020647437CB06BE0 (void);
// 0x00000083 System.Object FishCatching_<FishBit>d__31::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CFishBitU3Ed__31_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mD9344FEC5F70A4BC803CF86B201E9D677324DE33 (void);
// 0x00000084 System.Void FishCatching_<FishBit>d__31::System.Collections.IEnumerator.Reset()
extern void U3CFishBitU3Ed__31_System_Collections_IEnumerator_Reset_m6FB16E8147D611B146DA2578978D8A2B54392CFB (void);
// 0x00000085 System.Object FishCatching_<FishBit>d__31::System.Collections.IEnumerator.get_Current()
extern void U3CFishBitU3Ed__31_System_Collections_IEnumerator_get_Current_m367443328D1CBE9A81D91B207207150D1EDA313D (void);
// 0x00000086 System.Void Player_<disablePowerText>d__25::.ctor(System.Int32)
extern void U3CdisablePowerTextU3Ed__25__ctor_mCC0C6B19E7A85613F01D1C2F67A8C63BBEA84535 (void);
// 0x00000087 System.Void Player_<disablePowerText>d__25::System.IDisposable.Dispose()
extern void U3CdisablePowerTextU3Ed__25_System_IDisposable_Dispose_m6CAE322F2E17D597C78D1FFF75CDB6418E336A21 (void);
// 0x00000088 System.Boolean Player_<disablePowerText>d__25::MoveNext()
extern void U3CdisablePowerTextU3Ed__25_MoveNext_m7CDE5835919F623F9AA57DDAE009824D7A0D19CD (void);
// 0x00000089 System.Object Player_<disablePowerText>d__25::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CdisablePowerTextU3Ed__25_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m583AEE2553C73441316A63062051E196DD290CAD (void);
// 0x0000008A System.Void Player_<disablePowerText>d__25::System.Collections.IEnumerator.Reset()
extern void U3CdisablePowerTextU3Ed__25_System_Collections_IEnumerator_Reset_mF7137692397BDE27DA6B843A6947971D70816560 (void);
// 0x0000008B System.Object Player_<disablePowerText>d__25::System.Collections.IEnumerator.get_Current()
extern void U3CdisablePowerTextU3Ed__25_System_Collections_IEnumerator_get_Current_m7F4867CB4060A14FE403CD145DBB9C043AD8DA2E (void);
// 0x0000008C System.Void SceneLoader_<LoadLevel>d__5::.ctor(System.Int32)
extern void U3CLoadLevelU3Ed__5__ctor_m1132147078A8225FB324CA399E604AB243EC31F6 (void);
// 0x0000008D System.Void SceneLoader_<LoadLevel>d__5::System.IDisposable.Dispose()
extern void U3CLoadLevelU3Ed__5_System_IDisposable_Dispose_m5B5857265C6D10A79BD3B71E0445CE32239D7A05 (void);
// 0x0000008E System.Boolean SceneLoader_<LoadLevel>d__5::MoveNext()
extern void U3CLoadLevelU3Ed__5_MoveNext_m11034D67B1B86E6C9FB4A463CA6970452D382E05 (void);
// 0x0000008F System.Object SceneLoader_<LoadLevel>d__5::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CLoadLevelU3Ed__5_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m556B7401613899D4718EB5273C72A5E796D88B1E (void);
// 0x00000090 System.Void SceneLoader_<LoadLevel>d__5::System.Collections.IEnumerator.Reset()
extern void U3CLoadLevelU3Ed__5_System_Collections_IEnumerator_Reset_m7CFB0D3351AAA56A0B6A5A03557BF07AA3F4EA41 (void);
// 0x00000091 System.Object SceneLoader_<LoadLevel>d__5::System.Collections.IEnumerator.get_Current()
extern void U3CLoadLevelU3Ed__5_System_Collections_IEnumerator_get_Current_m810CB1DF04138D4F962A6453ACB9B367EB055DCF (void);
// 0x00000092 System.Void UnityTemplateProjects.SimpleCameraController_CameraState::SetFromTransform(UnityEngine.Transform)
extern void CameraState_SetFromTransform_m6467352ED87301E5F4A76456060A765CAB96AF3E (void);
// 0x00000093 System.Void UnityTemplateProjects.SimpleCameraController_CameraState::Translate(UnityEngine.Vector3)
extern void CameraState_Translate_m76BCC104A48EA7F125D5A50D874A2DEEA7967247 (void);
// 0x00000094 System.Void UnityTemplateProjects.SimpleCameraController_CameraState::LerpTowards(UnityTemplateProjects.SimpleCameraController_CameraState,System.Single,System.Single)
extern void CameraState_LerpTowards_m883AAF2D3C7F5045B64CAF655FB84EF0FC98F282 (void);
// 0x00000095 System.Void UnityTemplateProjects.SimpleCameraController_CameraState::UpdateTransform(UnityEngine.Transform)
extern void CameraState_UpdateTransform_mE3349362276789C1617C01276F7DE533BBA22623 (void);
// 0x00000096 System.Void UnityTemplateProjects.SimpleCameraController_CameraState::.ctor()
extern void CameraState__ctor_m4A83DF36C7D280050EA1B101E61B7E345C31A322 (void);
static Il2CppMethodPointer s_methodPointers[150] = 
{
	Readme__ctor_m23AE6143BDABB863B629ADE701E2998AB8651D4C,
	Boat_Start_mEECD5ECA53299A8FEA3DF763E7AD5529903098DD,
	Boat_Update_m7FC5D5164202171B5F180CCF96D6A49C1D8F849B,
	Boat_ChangeWeight_m5E4D8CD32A3CB7350FB240B6A27ABAF40188B076,
	Boat_SinkBoat_mEEDD11B64B9DE186CB1937F5AF40A313CE1599CF,
	Boat__ctor_m8126A51C3AE04D6BA08FE3DCAA608C26953F66B1,
	DialogueManager_Start_m79D30C6CBBE5FB76D9421878F07DBBD5F0133F4E,
	DialogueManager_Update_mDB01533DDBF392EA865355F8457D104CD3515902,
	DialogueManager_PrintDialog_mE6825684CC2A6E9B65838597B52B44807AE45992,
	DialogueManager_StartDialogue_m0F37B5E6085116068994B8EDD767B085FEEEFA4A,
	DialogueManager_ShowMessage_m55D6C47EA94D37AE2DEA819B4A9DFA3A1A07008B,
	DialogueManager_DisplayModel_m9F53CBE2A7522F2E323CC84F94CE720E87EAEEA3,
	DialogueManager_StopDialogue_m15581B51735B3CF6C2AA87356A7C012B36F8C0C4,
	DialogueManager_ShowEndScreen_m4D40756A6D7BD8BC442A868E3EDE14E5A683DD73,
	DialogueManager_EndTransition_mA77FD45418331E9DECCB28D0E7FB258039D37E16,
	DialogueManager_TextPrint_m4C61B8B121BA016485BC4F9B0CC5DFD4DA54D576,
	DialogueManager_PlayDelayedSound_mA7ADBB491A6989694F2DFBCD86AAF66CE91161C8,
	DialogueManager__ctor_m12727264331970D05A390B4E86D3E36A2B49D711,
	DialogueManager__cctor_mBEC397E79DD98669EE07A84A458F29D81FE2C6C3,
	FishCatching_Start_m842D74677D95D5CF87FA6DC76C1D130BAC1599BB,
	FishCatching_Update_m81D336ABA2B4B0EAF08E7A965FC3D2DBC288ADEE,
	FishCatching_CommenceCatching_mA15D7584B172126F198E8FD6B52ADFCA170B48EC,
	FishCatching_CaughtFish_m88002DA218BFF3B9F1949BCFAF826DF65D4748C3,
	FishCatching_CaughtBottle_m060A33EAA3F922C82B0C6826A8D97235F1203953,
	FishCatching_CaughtKey_m6BA785FA04B1DF78F4A294943D322F0B41A020F6,
	FishCatching_CaughtChest_m54BCCA5F597222DC20B1DC8BD0D1B5A6881F117C,
	FishCatching_CaughtJunk_mB3F4D6993F9256F16A8CFC2020C37CAFD788DB6B,
	FishCatching_StopCatching_m60EBF8C97E16594CC811BD657568E7183668985D,
	FishCatching_AddModelDeck_mA2B6CD7A17AB822147CE8BF087AC4FE7E33E1832,
	FishCatching_FishCatchDelay_m9C520FC98449018AA355CF818D9655FACEF1FCFA,
	FishCatching_FishBit_mC051FA2FEA0127A1D8745250FB9D37258F661783,
	FishCatching__ctor_mB1E0F6F50766F77E0737B3E4755F16E132DE8864,
	GameManager_get_FishAmount_m5C40B20D34F685110B61469C3C5302779589E9C5,
	GameManager_set_FishAmount_mEA9767821A5128BAD2ED4E7ACC5D1A4C9A3FA21C,
	GameManager_get_LastWeight_mF005EFF2A4E39A163DE57F8BC9F938952FC4AAB3,
	GameManager_set_LastWeight_m82CC9B198D8C80C8DBA772FE23070E9D8FF961D1,
	GameManager_get_BottleGet_mE2D1D3851DED7A76C3D305899C70D46A1891893D,
	GameManager_set_BottleGet_m65493ED8EE273FF32A0C99D5AFEED9FF9CA0C606,
	GameManager_get_ChestGet_m55142069696A0D732F07683473EE8FA3C04B762A,
	GameManager_set_ChestGet_mB6F183775E728BDD66E71FDCF5B6735162E3B4F1,
	GameManager_get_KeyGet_mB74A4963901A925302D88B474E015C1DAAC0822D,
	GameManager_set_KeyGet_m3DAFB1C841E812CE51008CAD6E18D804E0BBD6B4,
	GameManager_get_GameEnd_m05D2E0B5902A449F3D4E636E930E6B2DEBC58575,
	GameManager_set_GameEnd_m603A169E1DF85F8F7F0D780533968530525EF1FC,
	GameManager_get_CamClampAngleYMax_mF472229EAA736B07BD92B9647B2D517465AA5784,
	GameManager_set_CamClampAngleYMax_m080973306617EDA47DD8CD77F710972C8A55E722,
	GameManager_get_CamClampAngleYMin_mAC281A71089477B199FBB6D937D7C68ABC1DCFB1,
	GameManager_set_CamClampAngleYMin_m93E357A1F99A12EB5E8BB20A642F2DF65BB72920,
	GameManager_ResetClamp_m5378BC8993B67C60FB254A2DC227F89427EE141D,
	GameManager_Start_m4B67F69CF18652603C29FC1C5B7C6482C77B69DB,
	GameManager_Update_mB18435F2FDDC6175F5A83AB40198635F26D6FBFB,
	GameManager_EndGame_mA4F27563F51531B327D8A7AADF3D7B0A5172C539,
	GameManager__ctor_mFBEDEFD70BE58F3D3BE07FA8F9D97DE156D5C358,
	MainMenu_Start_mDF8837F303DD240CE4438A6ABC3D07F7D9B3620E,
	MainMenu_Back_m793A776DA6C9E7D226BFD6564F5C0C992B06F57D,
	MainMenu_StartGame_mFC02626170D8FD8351C02FDAE8E0E3FE90ABBC91,
	MainMenu_Help_mA56CF1BB734B561414B3694E82EDF48D81FC9E5B,
	MainMenu_Exit_m3BB3296C6F5C9DD08F770F6B9B5FE51B14A58031,
	MainMenu__ctor_m63F945D965550BD614DCD2AE7F7489D4F28C5B30,
	MouseLook_Start_mEEA4981192190CE14347F5C3CEC2E533956F8F23,
	MouseLook_Update_mD355F46C9D86DE6D5E64AD83D3C718950AD5775A,
	MouseLook_CameraInit_mDD36DACE45DEC4E5F4AA1DCE0DEFD9A87901E7CE,
	MouseLook_Rotate_m8BE2026BFB6299789ADF2660091F81E183610936,
	MouseLook__ctor_m376647F34A657513EEE22970CC3F58ED04F76776,
	ObjectSpin_Update_mA93635E38CCF07CF065E85B957FB9D7F39A7E2A2,
	ObjectSpin__ctor_m4442AA38911B03F646CF2288E510D8ACC5C36318,
	Player_Start_mD6E1D31879EB485356D1C22C8AE12C5DF6392E79,
	Player_Update_m10202D3DF1DE1AD29B6B00E0092D9C41BD3861F7,
	Player_ChargeRod_m8B975BA094F5227756DBCD104ED7100983F8D2E7,
	Player_ThrowBait_mEB5F69FBC7E90C639BBE8A96FAA511DC262567D1,
	Player_SetBaitLine_mDB090D642C7C26C15BFE83A0BD43270E62D27EA0,
	Player_SetPointerPos_m1F71EF4108A092B8E2C0CEDB4D24E6241F80F371,
	Player_disablePowerText_mF38CAFF2E7948D0639C3AEB83B75EE020A622F14,
	Player__ctor_mAEC38956EFD0E61D848D4E5AFB83BABCE2DF1E23,
	SceneLoader_LoadGame_mB3D4D41C90B61E5ED79315711AD5E402B54F0D5C,
	SceneLoader_BackToMainMenu_m79EB35A84B02551EBE237803498CA9C4E87F5AC1,
	SceneLoader_LoadLevel_m8739D17B6847C7DB5AC73A5DF0D647FCE22ED89C,
	SceneLoader__ctor_mC60F58BE3954C3DF24116E3C07079A7FAC27E784,
	SceneLoader__cctor_m74D4EDDA5F712004EA7023E91D380BA1182831DC,
	SoundManager_Awake_mB15DF04ADE8728C5E6223B353D7C921095F633C7,
	SoundManager_Play_m2B090969A0D0B4F72465FF82315B0C2C59D50106,
	SoundManager_PlayMusic_m2CC702A2235E41FD54735BD20EEA2FA6DF098538,
	SoundManager_PlayMusicSecond_mF6A7C60C4B8628D865D44D7D06989A30FEB5D4AB,
	SoundManager_RandomSoundEffect_m846A2F63576DF8E094E8B40994D45DE41629AA15,
	SoundManager__ctor_mD7EC9DED92E2CC5E0271C72E21077FC66D780507,
	SoundManager__cctor_mCC84F889230E77BD79067F9B963F41F2C223B2F0,
	UIManager_Start_mA404E1D4B4AA55F22307F16D7D7842CE7580DD0B,
	UIManager_UpdateFishAmount_mE212065ACD97F337B0DE432BA326E8992F91F838,
	UIManager_UpdateBoatWeight_m164E3A183D6C0539A06A55FFB19A8496AD252A40,
	UIManager_EnableBottleFull_m8D22EA193BCDC13897A9C6CE19E61C320BA57035,
	UIManager_EnableBottleEmpty_m4D87F65506B2C6F7A2472256A7C73718925DED29,
	UIManager_EnableKey_mF20148F31A6E71BE806F4D9C9AB24DF6489FB85A,
	UIManager_EnableChest_m4CCE6FE0D2F90498BE92BA930CFBB5C45F503D66,
	UIManager_EnableBoatSank_mABDEA5C11BBCF5ECD493BFD60C1C051A859BDB8F,
	UIManager_EnableAlert_m2DC4EC733D05A64EF409DA18BDC4AB2F3BD9736E,
	UIManager_SetPowerText_m85B3824502A86EFDD691C174F022016A2A0B962B,
	UIManager_RollCredits_m642537447B0EDB4F1556FE5AA0E10EE9C9DC993A,
	UIManager__ctor_m5E5065654115BEE5B00F84AC64469D5D642351A3,
	SimpleCameraController_OnEnable_mE3D6E47455F101F2DEEBC2A58D09A97CF38E80B8,
	SimpleCameraController_GetInputTranslationDirection_m73C99DB69CEB467834BBA00A62415D1CEEF0CB47,
	SimpleCameraController_Update_mBCD24408A4A2C4053F2F98DB808BD6DE88CA998F,
	SimpleCameraController__ctor_m8DE12FC1A6C31D2D60ED78F0B574CE3F864F546E,
	Section__ctor_mE73C1D6AE5454B5A67AAB04CAA5144A5CA0B0D96,
	U3CEndTransitionU3Ed__39__ctor_mF56ACAED40BC2755C4550FEC7017C227C72EE988,
	U3CEndTransitionU3Ed__39_System_IDisposable_Dispose_mCA4BFA0602588410FF781BBA32B8B1FFBC4C4667,
	U3CEndTransitionU3Ed__39_MoveNext_m09C1B2E498E89309BB1DCD3CEBCF4667C9283D4D,
	U3CEndTransitionU3Ed__39_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m03932AC1FD81878391039E7A40CC46A15EE2CE64,
	U3CEndTransitionU3Ed__39_System_Collections_IEnumerator_Reset_m41ABE9315CB73037B0B4769E292D29E73953DB64,
	U3CEndTransitionU3Ed__39_System_Collections_IEnumerator_get_Current_m54001C6490F198FDFCF72ABBBE7DA2FFC1F1F409,
	U3CTextPrintU3Ed__40__ctor_mE16F9FF0EF2AF05457794768F17085008DDC053A,
	U3CTextPrintU3Ed__40_System_IDisposable_Dispose_m373CB6259DEFC94052D404070D83EBF4ED89BA45,
	U3CTextPrintU3Ed__40_MoveNext_m9F7DD58C30FDD1D0B48B95F2C6F82DF8CB6D5307,
	U3CTextPrintU3Ed__40_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m544B913E4716A0526DB7EEEEFD11DCD8E7E4CE5C,
	U3CTextPrintU3Ed__40_System_Collections_IEnumerator_Reset_m8AB3995F050EBCDE21ECA084505DF6C2ED89EDCD,
	U3CTextPrintU3Ed__40_System_Collections_IEnumerator_get_Current_m38ECC1B5F708102FFD9F8B62A2666D7F8A801BBC,
	U3CPlayDelayedSoundU3Ed__41__ctor_m5C03889C50359DE37BD5FFA075BB8DDC88EE6847,
	U3CPlayDelayedSoundU3Ed__41_System_IDisposable_Dispose_mB0A639B29C031AA533864685F594BB776456221D,
	U3CPlayDelayedSoundU3Ed__41_MoveNext_m1A55D7BA4282AED5D8CDEE72E47A1FEC2D0BC12C,
	U3CPlayDelayedSoundU3Ed__41_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mD5323B22FA8F936554BA64E5F3A3688C908A887B,
	U3CPlayDelayedSoundU3Ed__41_System_Collections_IEnumerator_Reset_mD98FD8648ED1560A06A7AA1ED9485D06F6E2FA57,
	U3CPlayDelayedSoundU3Ed__41_System_Collections_IEnumerator_get_Current_m4A82F673CBD3540999951996AC3FC788C8904316,
	U3CFishCatchDelayU3Ed__30__ctor_m274B09FA4F96C8D3BE85423C28C15BF526C5451A,
	U3CFishCatchDelayU3Ed__30_System_IDisposable_Dispose_mAEDAD82F038168EE8815D24DF905586BDE7A8E7C,
	U3CFishCatchDelayU3Ed__30_MoveNext_m8EF5B75AAAF812F5F60C566AA5B8147F9C25CAE0,
	U3CFishCatchDelayU3Ed__30_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m7B217589608D2B3883F462FEBD69277479527056,
	U3CFishCatchDelayU3Ed__30_System_Collections_IEnumerator_Reset_m6DD779F2B721FCAFDDE91D448891B354F9EFE661,
	U3CFishCatchDelayU3Ed__30_System_Collections_IEnumerator_get_Current_m6D1B4FCF314BCC0B1ECA6A5E41C910EE708CAE85,
	U3CFishBitU3Ed__31__ctor_m504CB3444F7CAEDE4F0918F3363B7DEC2C45F36B,
	U3CFishBitU3Ed__31_System_IDisposable_Dispose_m71B5B022FF0006086D14CE74D59258998B169408,
	U3CFishBitU3Ed__31_MoveNext_mE32D5E2866C14B1B8AF577A9020647437CB06BE0,
	U3CFishBitU3Ed__31_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mD9344FEC5F70A4BC803CF86B201E9D677324DE33,
	U3CFishBitU3Ed__31_System_Collections_IEnumerator_Reset_m6FB16E8147D611B146DA2578978D8A2B54392CFB,
	U3CFishBitU3Ed__31_System_Collections_IEnumerator_get_Current_m367443328D1CBE9A81D91B207207150D1EDA313D,
	U3CdisablePowerTextU3Ed__25__ctor_mCC0C6B19E7A85613F01D1C2F67A8C63BBEA84535,
	U3CdisablePowerTextU3Ed__25_System_IDisposable_Dispose_m6CAE322F2E17D597C78D1FFF75CDB6418E336A21,
	U3CdisablePowerTextU3Ed__25_MoveNext_m7CDE5835919F623F9AA57DDAE009824D7A0D19CD,
	U3CdisablePowerTextU3Ed__25_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m583AEE2553C73441316A63062051E196DD290CAD,
	U3CdisablePowerTextU3Ed__25_System_Collections_IEnumerator_Reset_mF7137692397BDE27DA6B843A6947971D70816560,
	U3CdisablePowerTextU3Ed__25_System_Collections_IEnumerator_get_Current_m7F4867CB4060A14FE403CD145DBB9C043AD8DA2E,
	U3CLoadLevelU3Ed__5__ctor_m1132147078A8225FB324CA399E604AB243EC31F6,
	U3CLoadLevelU3Ed__5_System_IDisposable_Dispose_m5B5857265C6D10A79BD3B71E0445CE32239D7A05,
	U3CLoadLevelU3Ed__5_MoveNext_m11034D67B1B86E6C9FB4A463CA6970452D382E05,
	U3CLoadLevelU3Ed__5_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m556B7401613899D4718EB5273C72A5E796D88B1E,
	U3CLoadLevelU3Ed__5_System_Collections_IEnumerator_Reset_m7CFB0D3351AAA56A0B6A5A03557BF07AA3F4EA41,
	U3CLoadLevelU3Ed__5_System_Collections_IEnumerator_get_Current_m810CB1DF04138D4F962A6453ACB9B367EB055DCF,
	CameraState_SetFromTransform_m6467352ED87301E5F4A76456060A765CAB96AF3E,
	CameraState_Translate_m76BCC104A48EA7F125D5A50D874A2DEEA7967247,
	CameraState_LerpTowards_m883AAF2D3C7F5045B64CAF655FB84EF0FC98F282,
	CameraState_UpdateTransform_mE3349362276789C1617C01276F7DE533BBA22623,
	CameraState__ctor_m4A83DF36C7D280050EA1B101E61B7E345C31A322,
};
static const int32_t s_InvokerIndices[150] = 
{
	23,
	23,
	23,
	32,
	23,
	23,
	23,
	23,
	27,
	32,
	31,
	110,
	23,
	23,
	14,
	28,
	58,
	23,
	3,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	14,
	14,
	23,
	10,
	32,
	10,
	32,
	114,
	31,
	114,
	31,
	114,
	31,
	114,
	31,
	686,
	296,
	686,
	296,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	34,
	23,
	3,
	23,
	26,
	26,
	26,
	26,
	23,
	3,
	23,
	23,
	32,
	31,
	31,
	31,
	31,
	31,
	31,
	2233,
	23,
	23,
	23,
	1129,
	23,
	23,
	23,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	26,
	1130,
	1302,
	26,
	23,
};
extern const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule = 
{
	"Assembly-CSharp.dll",
	150,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
